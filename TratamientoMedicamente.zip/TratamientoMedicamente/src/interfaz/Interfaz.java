package interfaz;

import Credenciales.Administrador;
import Credenciales.Paciente;
import java.util.ArrayList;
import java.util.Scanner;
import mundo.Medicamento;
import mundo.Tratamiento;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Interfaz {

    private ArrayList<Paciente> pacientes;
    private ArrayList<Administrador> administradores;

    public Interfaz() {
        pacientes = new ArrayList<>();
        administradores = new ArrayList<>();
        Inicializar();
    }

    private void Inicializar() {
        getPacientes().add(new Paciente("Juan", "1043827438", "31621312231", true));
        getPacientes().add(new Paciente("David", "1032112321", "31313212231", false));
        getPacientes().add(new Paciente("Felipe", "1037892341", "3102571321", true));
        getPacientes().add(new Paciente("Brayan", "1031462345", "3121334122", false));
        getPacientes().add(new Paciente("Maria", "52763921", "313846123", true));
        getPacientes().add(new Paciente("Alejandra", "38591234", "3216483712", false));

        getDoctores().add(new Administrador("Juan", "1043827438", "31621312231"));
        getDoctores().add(new Administrador("David", "1032112321", "31313212231"));
        getDoctores().add(new Administrador("Felipe", "1037892341", "3102571321"));
        getDoctores().add(new Administrador("Brayan", "1031462345", "3121334122"));
        getDoctores().add(new Administrador("Maria", "52763921", "313846123"));
        getDoctores().add(new Administrador("Alejandra", "38591234", "3216483712"));
    }

    public String mostrarDoctores() {
        String s = "";
        for (Administrador d : getDoctores()) {
            s += d + "\n";
        }
        return s;
    }

    public Paciente buscarPaciente(String cc) {
        for (Paciente p : getPacientes()) {
            if (p.getCC().equals(cc)) {
                return p;
            }
        }
        return null;
    }

    public boolean verificarPaciente(String cc) {
        boolean x = false;
        for (Paciente p : getPacientes()) {
            if (p.getCC().equals(cc)) {
                x = true;
            }
        }
        return x;
    }

    /**
     * @return the pacientes
     */
    public ArrayList<Paciente> getPacientes() {
        return pacientes;
    }

    /**
     * @return the doctores
     */
    public ArrayList<Administrador> getDoctores() {
        return administradores;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Interfaz iApp = new Interfaz();
        String cc;
        int dia, mes, año;
        boolean x = false;
        Paciente paciente;
        Tratamiento tr;
        Medicamento me;
        // Tratamiento tr = new Tratamiento(23, 11, 2023, "Cra 95A #135-34", "RR");
        //System.out.println(tr.getReceta());

        while (true) {

            System.out.println("Ingrese el numero de cedula del administrador: ");
            cc = sc.nextLine();
            for (Administrador a : iApp.getDoctores()) {
                if (a.getCC().equals(cc)) {
                    System.out.println("\nBienvenido\n"
                            + a.toString() + "\n");
                    x = true;
                    break;
                }
            }

            if (x == false) {
                System.out.println("Por favor ingrese nuevamente las credenciales.");
            }
            while (x) {

                do {
                    System.out.println("Ingrese la cedula del paciente: ");
                    cc = sc.nextLine();
                } while (!iApp.verificarPaciente(cc));

                paciente = iApp.buscarPaciente(cc);

                System.out.println("Que desea hacer? \n"
                        + "1. Ingresar el tratamiento de un paciente.\n"
                        + "2. Ingresar los medicamentos de un paciente.\n");
                int opcion = sc.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Ingrese el dia, mes y año de la fecha del tratamiento: ");
                        dia = sc.nextInt();
                        mes = sc.nextInt();
                        año = sc.nextInt();

                        System.out.println("Ingrese el lugar del tratamiento: ");
                        String lugar = sc.nextLine();
                        sc.nextLine();
                        System.out.println("Ingrese el nombre del tratamiento: ");
                        String nomTratamiento = sc.nextLine();

                        tr = new Tratamiento(dia, mes, año, lugar, nomTratamiento, paciente);
                        System.out.println(tr.getReceta());
                        break;

                    case 2:
                        sc.nextLine();
                        System.out.println("Ingrese el dia, mes y año de la fecha del tratamiento: ");
                        dia = sc.nextInt();
                        mes = sc.nextInt();
                        año = sc.nextInt();

                        sc.nextLine();
                        System.out.println("Ingrese el nombre del medicamento: ");
                        String nomMedicamento = sc.nextLine();

                        System.out.println("Ingrese la cantidad del medicamento: ");
                        int cantidad = sc.nextInt();

                        me = new Medicamento(dia, mes, año, nomMedicamento, cantidad, paciente);
                        System.out.println(me.getReceta());
                        break;

                    default:
                        System.out.println("Opcion no valida.");
                        break;
                }
            }

        }

    }

}
