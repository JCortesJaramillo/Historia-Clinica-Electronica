package Credenciales;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Administrador {

    private final String nombre;
    private final String CC;
    private final String numTelefono;

    public Administrador(String nombre, String CC, String numTelefono) {
        this.nombre = nombre;
        this.CC = CC;
        this.numTelefono = numTelefono;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the CC
     */
    public String getCC() {
        return CC;
    }

    /**
     * @return the numTelefono
     */
    public String getNumTelefono() {
        return numTelefono;
    }

    @Override
    public String toString() {
        return "Administrador{" + "nombre = " + nombre + ", CC = " + CC + ", numero de telefono = " + numTelefono + '}';
    }

}
