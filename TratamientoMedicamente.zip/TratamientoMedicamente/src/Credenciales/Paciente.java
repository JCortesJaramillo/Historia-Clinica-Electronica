package Credenciales;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Paciente {

    private final String nombre;
    private final String CC;
    private final String numTelefono;
    private boolean restriccion;

    public Paciente(String nombre, String CC, String numTelefono, boolean restriccion) {
        this.nombre = nombre;
        this.CC = CC;
        this.numTelefono = numTelefono;
        this.restriccion = restriccion;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the CC
     */
    public String getCC() {
        return CC;
    }

    /**
     * @return the numTelefono
     */
    public String getNumTelefono() {
        return numTelefono;
    }

    public String restriccion() {
        String s = "";
        if (isRestriccion()) {
            s += "El paciente posee una restriccion, no entregar ni medicamentos ni tratamientos";
        } else {
            s += "El paciente no posee ninguna restriccion";
        }
        return s;
    }

    /**
     * @return the restriccion
     */
    public boolean isRestriccion() {
        return restriccion;
    }

    @Override
    public String toString() {
        return "Paciente{" + "nombre = " + nombre + ", CC = " + CC + ", numero de telefono = " + numTelefono + ", Restricciones = " + restriccion() + '}';
    }

}
