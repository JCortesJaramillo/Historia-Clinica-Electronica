package mundo;

import Credenciales.Paciente;
import java.time.LocalDate;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Tratamiento {

    private int dia;
    private int mes;
    private int año;
    private String lugar;
    private String receta;
    private String nomTratamiento;
    private Paciente p;

    public Tratamiento(int dia, int mes, int año, String lugar, String nomTratamiento, Paciente p) {
        this.p = p;
        this.año = año;
        this.dia = dia;
        this.mes = mes;
        this.lugar = lugar;
        this.nomTratamiento = nomTratamiento;
        receta = receta(dia, mes, año);
    }

    private String receta(int dia, int mes, int año) {
        String s = "";
        if (verificarFecha(dia, mes, año)) {
            if (p.isRestriccion()) {
                System.out.println(p.restriccion());
            } else {
                s += "El tratamiento sera en la fecha: " + dia + "/" + mes + "/" + año + ".\n"
                        + "Nombre de tratamiento: " + nomTratamiento + ".\n"
                        + "Por favor, respetar la fecha del tratamiento y llegar al lugar: " + lugar + "\n"
                        + "paciente " + p.getNombre() + " con cedula " + p.getCC() + ".";
            }
        } else {
            s += "Fecha ingresada no valida";
        }
        return s;
    }

    private boolean verificarFecha(int dia, int mes, int año) {
        LocalDate fechaIngresada = LocalDate.of(año, mes, dia);
        LocalDate fechaActual = LocalDate.now();

        if (fechaIngresada.isBefore(fechaActual)) {
            return false;
        } else if (fechaIngresada.isEqual(fechaActual)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @return the receta
     */
    public String getReceta() {
        return receta;
    }

}
