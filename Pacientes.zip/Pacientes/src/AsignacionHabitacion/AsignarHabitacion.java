package AsignacionHabitacion;

import IngresoPaciente.IngresarPaciente;
import Paciente.Paciente;
import RegistrarPaciente.RegistrarPaciente;
import java.util.ArrayList;

/**
 *
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class AsignarHabitacion {
    private ArrayList<Paciente> pacienteIngresado;
    private Paciente[] habitacion;
    private IngresarPaciente ip;
    private static AsignarHabitacion instance;
    private int contador;
    
    private AsignarHabitacion(IngresarPaciente ip){
       pacienteIngresado = ip.getPacienteIngresado();
       habitacion = new Paciente[10];
       inicializar();
       this.ip = ip;
       contador = 0;
    }
    
    private void inicializar(){
        for (int i = 0; i < habitacion.length; i++) {
            habitacion[i] = null;
        }
    }
    
    public static AsignarHabitacion getInstance(IngresarPaciente ip){
        if (instance == null) {
           instance = new AsignarHabitacion(ip);
        }
        return instance;
    }
    
    public boolean registrarObservador(Paciente p){
        while(true){
            int ran = (int) (Math.random() * 9);
            if (habitacion[ran] == null) {
                p.setHabitacion(ran+1);
                habitacion[ran] = p;
                contador++;
                return true;
            }
        }
    }
    
    public void eliminarObservador(int numRegistro){
        for (int i = 0; i < habitacion.length; i++) {
            if (habitacion[i].getNumRegistro() == numRegistro) {
                habitacion[i] = null;
            }
        }
    }
    
    public String notificar(){
        String s = "";
        for (int i = 0; i < habitacion.length; i++) {
            if (habitacion[i] != null) {
                s += "Se notifico a " +habitacion[i].getNombre()+ " con numero de registro " +habitacion[i].getNumRegistro()+" sobre su "
                        + "habitacion " + (i+1) + "\n";
            }
        }
        return s;
    }
    
}
