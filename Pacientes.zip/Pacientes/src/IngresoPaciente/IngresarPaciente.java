package IngresoPaciente;

import Paciente.Paciente;
import RegistrarPaciente.RegistrarPaciente;
import java.util.ArrayList;

/**
 *
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class IngresarPaciente {
    private ArrayList<Paciente> pacienteRegistrado;
    private ArrayList<Paciente> pacienteIngresado;
    private RegistrarPaciente rp;
    private static IngresarPaciente instance;
    
    private IngresarPaciente(RegistrarPaciente rp){
        pacienteRegistrado = rp.getPacientes();
        pacienteIngresado = new ArrayList<>();
        this.rp = rp;
    }     
    
    public static IngresarPaciente getInstance(RegistrarPaciente rp){
        if (instance == null) {
           instance = new IngresarPaciente(rp);
        }
        return instance;
    }
    
    private Paciente buscarPaciente(String CC, int numRegistro){
        for(Paciente p: pacienteRegistrado){
            if (p.getCC().equals(CC) && p.getNumRegistro() == numRegistro) {
                return p;
            }
        }
        return null;
    }
    
    public boolean Ingreso(String cc, int numRegistro, String motivo){
        Paciente p = buscarPaciente(cc, numRegistro);
        if (p != null) {
            if (p.getMotivo().equals("")) {
                p.setMotivo(motivo);
                getPacienteIngresado().add(p);
                rp.retirarPaciente(numRegistro);
                return true;
            }
        }
        return false;
    }
    
    public Paciente retirarPaciente(int numRegistro){
        for(Paciente p : getPacienteIngresado()){
            if (p.getNumRegistro() == numRegistro) {
                getPacienteIngresado().remove(p);
                return p;
            }
        }
        return null;
    }
      
    public String mostrarPacienteIngresado(){
        String s = "";
        for(Paciente p : getPacienteIngresado()){
            s += p.toString()+"\n";
        }
        return s;
    }

    /**
     * @return the pacienteIngresado
     */
    public ArrayList<Paciente> getPacienteIngresado() {
        return pacienteIngresado;
    }
}
