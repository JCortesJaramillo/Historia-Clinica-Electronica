package Interfaz;
import AsignacionHabitacion.AsignarHabitacion;
import IngresoPaciente.IngresarPaciente;
import Paciente.*;
import RegistrarPaciente.RegistrarPaciente;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Interfaz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    RegistrarPaciente rp = RegistrarPaciente.getInstance();
    IngresarPaciente ip = IngresarPaciente.getInstance(rp);
    AsignarHabitacion ah = AsignarHabitacion.getInstance(ip);
    
        for (int i = 0; i < 10; i++) {
            rp.registrar(new Paciente("A", "123","Famisanar",rp.getContador(),"",0));
        }
        
        System.out.println(rp.mostrarPaciente());

        ip.Ingreso("123", 2, "Dolor de cabeza y presion en el pecho");
        ip.Ingreso("123", 4, "Dolor de cabeza presion en el pecho");
        ip.Ingreso("123", 6, "Dolor de cabeza resion en el pecho");
        ip.Ingreso("123", 8, "Dolor de cabeza esion en el pecho");
        ip.Ingreso("123", 10, "Dolor de cabeza ion en el pecho");

        System.out.println(rp.mostrarPaciente());
        
        System.out.println("Pacientes ingresados: \n"
                + ip.mostrarPacienteIngresado());
        
        for(Paciente p : ip.getPacienteIngresado()){
            ah.registrarObservador(p);
        }
        
        System.out.println(ah.notificar());
        System.out.println(ip.mostrarPacienteIngresado());

    }
    
}
