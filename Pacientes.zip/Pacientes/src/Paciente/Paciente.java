package Paciente;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Paciente {

    private final String nombre;
    private final String CC;
    private final String eps;
    private final int numRegistro;
    private String motivo;
    private int habitacion;

    public Paciente(String nombre, String CC, String eps, int numRegistro, String motivo, int habitacion) {
        this.nombre = nombre;
        this.CC = CC;
        this.eps = eps;
        this.numRegistro = numRegistro;
        this.motivo = motivo;
        this.habitacion = habitacion;
    }

//    public static Paciente getInstance(String nombre, int CC, String eps, String numRegistro){
//       if (instance == null) {
//           instance = new Paciente(nombre, CC, eps, numRegistro);
//       }
//       return instance; 
//    }
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the CC
     */
    public String getCC() {
        return CC;
    }

    /**
     * @return the eps
     */
    public String getEps() {
        return eps;
    }

    /**
     * @return the numRegistro
     */
    public int getNumRegistro() {
        return numRegistro;
    }

    /**
     * @return the motivo
     */
    public String getMotivo() {
        return motivo;
    }

    /**
     * @param motivo the motivo to set
     */
    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    /**
     * @return the habitacion
     */
    public int getHabitacion() {
        return habitacion;
    }

    /**
     * @param habitacion the habitacion to set
     */
    public void setHabitacion(int habitacion) {
        this.habitacion = habitacion;
    }
   
    @Override
    public String toString() {
        return "Paciente{" + "nombre = " + nombre + ", CC = " + CC + ", eps = " + eps + ", numeroRegistro = " + numRegistro + ", motivo = " + motivo +
                ", habitacion = " +getHabitacion()+'}';
    }

}
