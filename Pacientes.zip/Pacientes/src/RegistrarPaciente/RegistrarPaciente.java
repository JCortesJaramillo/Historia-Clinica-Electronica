package RegistrarPaciente;

import Paciente.Paciente;
import java.util.ArrayList;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class RegistrarPaciente {
    private ArrayList<Paciente> pacientes;
    private int contador;
    private static RegistrarPaciente instance;
    
    private RegistrarPaciente(){
        pacientes = new ArrayList<>();
        contador = 1;
    }
    
    public static RegistrarPaciente getInstance(){
       if (instance == null) {
           instance = new RegistrarPaciente();
       }
       return instance;
    }
    
    
    public void registrar(Paciente p){
        getPacientes().add(p);
        contador++;
    }
    
    public Paciente retirarPaciente(int numRegistro){
        for(Paciente p : getPacientes()){
            if (p.getNumRegistro() == numRegistro) {
                getPacientes().remove(p);
                return p;
            }
        }
        return null;
    }
    
    public String mostrarPaciente(){
        String s = "";
        for(Paciente p : getPacientes()){
            s += p.toString()+"\n";
        }
        return s;
    }

    /**
     * @return the contador
     */
    public int getContador() {
        return contador;
    }

    /**
     * @return the pacientes
     */
    public ArrayList<Paciente> getPacientes() {
        return pacientes;
    }
    
}
