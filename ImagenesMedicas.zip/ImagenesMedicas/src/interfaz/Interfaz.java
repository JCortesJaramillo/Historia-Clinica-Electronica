package interfaz;

import java.util.ArrayList;
import java.util.Scanner;
import mundo.Doctor;
import mundo.ImagenesMedicas;
import mundo.Paciente;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Interfaz {
    private ArrayList<Paciente> pacientes;
    private ArrayList<Doctor> doctores;
    
    public Interfaz(){
        pacientes = new ArrayList<>();
        doctores = new ArrayList<>();
        Inicializar();
    }
    
    private void Inicializar(){
        getPacientes().add(new Paciente("Juan","1043827438","31621312231","jd@gmail.com"));
        getPacientes().add(new Paciente("David","1032112321","31313212231","DavidF@gmail.com"));
        getPacientes().add(new Paciente("Felipe","1037892341","3102571321","Pipe@gmail.com"));
        getPacientes().add(new Paciente("Brayan","1031462345","3121334122","Br@gmail.com"));
        getPacientes().add(new Paciente("Maria","52763921","313846123","Maria@gmail.com"));
        getPacientes().add(new Paciente("Alejandra","38591234","3216483712","Aa@gmail.com"));
        
        getDoctores().add(new Doctor("Juan","1043827438","31621312231","Docjd@gmail.com","Oncologia"));
        getDoctores().add(new Doctor("David","1032112321","31313212231","DocDavidF@gmail.com","Cardiologia"));
        getDoctores().add(new Doctor("Felipe","1037892341","3102571321","DocFelipe@gmail.com", "Oftalmologia"));
        getDoctores().add(new Doctor("Brayan","1031462345","3121334122","DocBr@gmail.com", "Dermatologia"));
        getDoctores().add(new Doctor("Maria","52763921","313846123","DocMaria@gmail.com", "Psicologia"));
        getDoctores().add(new Doctor("Alejandra","38591234","3216483712","DocAle@gmail.com", "Neurologia"));
    }
    
    public String mostrarDoctores(){
        String s = "";
        for(Doctor d : getDoctores()){
            s += d + "\n"; 
        }
        return s;
    }
    
    /**
     * @return the pacientes
     */
    public ArrayList<Paciente> getPacientes() {
        return pacientes;
    }

    /**
     * @return the doctores
     */
    public ArrayList<Doctor> getDoctores() {
        return doctores;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Interfaz iApp = new Interfaz();
        Scanner sc = new Scanner(System.in);
        ImagenesMedicas im = new ImagenesMedicas();
        //sc.nextLine();
        String cc;
        String dir;
        int indice;
        boolean x = false;
               
        while(true){
            System.out.println("Ingrese la cedula del paciente: ");
            cc = sc.nextLine();
            
            for(Paciente p : iApp.getPacientes()){
                //System.out.println(p.getCC());
                if (p.getCC().equals(cc)) {
                    System.out.println("\nPaciente encontrado\n"
                            + p.toString() + "\n");
                    x = true;
                    break;
                }
            }
            
            if (x == false) {
                System.out.println("Paciente no encontrado.");
            }
            
            while(x){
                System.out.println("Ingrese direccion de la imagen: ");
                dir = sc.nextLine();
                
                if (im.archivoExistente(dir)) {
                    System.out.println(iApp.mostrarDoctores());
                    do{
                        System.out.println("Elija el doctor que leera su imagen (indices de 1 a 6): ");
                        indice = sc.nextInt();
                    }while(indice < 1 || indice > 6);
                    
                    System.out.println(im.notificar(iApp.getDoctores(), dir, indice-1));
                    sc.nextLine();
                    break;
                }else{
                    System.err.println("Error, archivo no existente.");
                    break;
                }
            }
          
        }
    }

    
}
