package mundo;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Doctor {
    private final String nombre;
    private final String CC;
    private final String numTelefono;
    private final String correo;
    private final String cargo;

    public Doctor(String nombre, String CC, String numTelefono, String correo, String cargo) {
        this.nombre = nombre;
        this.CC = CC;
        this.numTelefono = numTelefono;
        this.correo = correo;
        this.cargo = cargo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the CC
     */
    public String getCC() {
        return CC;
    }

    /**
     * @return the numTelefono
     */
    public String getNumTelefono() {
        return numTelefono;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @return the cargo
     */
    public String getCargo() {
        return cargo;
    }

    @Override
    public String toString() {
        return "Doctor{" + "nombre = " + nombre + ", CC = " + CC + ", numTelefono = " + numTelefono + ", correo = " + correo + ", cargo = " + cargo + '}';
    }
    
    
}
