package mundo;

import java.io.File;
import java.util.ArrayList;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class ImagenesMedicas {
    
    public boolean archivoExistente(String dir){
        File archivo = new File(dir);
        return archivo.exists();
    }
    
    public String notificar(ArrayList arr, String dir, int indice){
        String s = "";
        Doctor d;
        if (archivoExistente(dir)) {
            d = (Doctor)arr.get(indice);
            s += "Se enviara la imagen " +dir+ " al doctor "+d.getNombre()+ " cuyo correo es "+d.getCorreo();
        }else{
            return null;
        }
        return s;
    }
}
