package mundo;

/**
 * @author Juan David Cortés, Brayan Felipe Albornoz
 */
public class Paciente {

    private final String nombre;
    private final String CC;
    private final String numTelefono;
    private final String correo;

    public Paciente(String nombre, String CC, String numTelefono, String correo) {
        this.nombre = nombre;
        this.CC = CC;
        this.numTelefono = numTelefono;
        this.correo = correo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the CC
     */
    public String getCC() {
        return CC;
    }

    /**
     * @return the numTelefono
     */
    public String getNumTelefono() {
        return numTelefono;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    @Override
    public String toString() {
        return "Paciente{" + "nombre = " + nombre + ", CC = " + CC + ", numero de telefono = " + numTelefono + ", correo = " + correo + '}';
    }

    

}
